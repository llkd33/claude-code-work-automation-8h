const fs = require('node:fs'), path = require('node:path');
try {
 const src = path.resolve('input/batch-demo'), dst = path.resolve('output/batch');
 const plan = fs.readdirSync(src,{withFileTypes:true}).filter(f=>f.isFile()&&f.name.endsWith('.txt')).sort((a,b)=>a.name.localeCompare(b.name)).map(f=>({from:path.join(src,f.name),to:path.join(dst,'2026-09_'+f.name.replace(/\s+/g,'_'))}));
 const targets = new Set();
 for(const item of plan){if(targets.has(item.to)||fs.existsSync(item.to))throw new Error('새 이름 충돌 또는 기존 목적지: '+item.to);targets.add(item.to);}
 console.log(JSON.stringify({mode:process.argv.includes('--apply')?'apply':'dry-run',count:plan.length,plan},null,2));
 if(process.argv.includes('--apply')){fs.mkdirSync(dst,{recursive:true});for(const item of plan)fs.copyFileSync(item.from,item.to,fs.constants.COPYFILE_EXCL);console.log('복사 완료. 원본 보존.');}
} catch(e){console.error('일괄 처리 중단: '+e.message);process.exitCode=1;}
