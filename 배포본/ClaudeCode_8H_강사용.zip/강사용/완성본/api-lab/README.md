# API 실습 강사 완성본

Node 22 이상. 추가 패키지·AI API 호출 없음. `weather.cjs`는 실습 생성 코드 비교용이며 학생 배포에는 제외합니다.

이 폴더에서:

```sh
node --test weather.test.cjs
node weather.cjs --fixture fixtures/weather-synthetic.json --output output/demo
node weather.cjs --fixture fixtures/weather-zero-synthetic.json --output output/zero
node weather.cjs --fixture fixtures/weather-invalid-synthetic.json --output output/zero
```

마지막 명령은 실패가 정답입니다. zero의 정상 결과가 바뀌지 않아야 합니다. fixture는 실제 날씨를 조회하거나 캡처한 값이 아닌 합성 데이터입니다. JSON·HTML에 DEMO와 synthetic 출처를 표시합니다.

Open-Meteo 무료 서비스의 비상업 조건을 확인한 경우에만 실제 API로 실행합니다. 기업 교육의 적격성을 자동으로 단정하지 않습니다. 조건이 맞지 않거나 판단이 어려우면 합성 모드 또는 JSONPlaceholder/Frankfurter 과제로 진행합니다. [공식 약관](https://open-meteo.com/en/terms)

```sh
node weather.cjs --output output/api
```

완료 조건: 두 결과파일, 데이터 기준시각과 생성시각, °C/%/WMO, 출처, 오류 보존, 0값 성공. API 현재값은 모델 기반입니다. 실패 시 DEMO로 자동 전환하지 않습니다. URL은 서울에 고정해 요청 범위를 작게 유지합니다.

교육장: 외부 HTTPS 허용과 공인IP 공유 한도 확인, 각자 API 1회만 호출. 인터넷 없이도 fixture 검사·화면 확인은 가능하지만 실제 연결 완료 체크는 따로 둡니다. 학습자는 코드 문법을 설명할 필요 없이 입력·결과·실패·다시 실행을 설명할 수 있으면 됩니다.
