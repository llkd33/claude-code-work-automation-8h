'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { run, validate, render } = require('./weather.cjs');
const fixture = path.join(__dirname, 'fixtures/weather-synthetic.json');
const payload = () => fs.readFile(fixture, 'utf8').then(JSON.parse);
const mock = data => async () => ({ok:true, status:200, json:async()=>data});
const clock = () => new Date('2026-01-15T00:01:00Z');
test('정상 API 응답이 단위/기준시각과 두 결과파일을 만든다', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(),'api-lab-'));
  t.after(()=>fs.rm(dir,{recursive:true,force:true}));
  const report = await run({ outputDir:dir,fetchImpl:mock(await payload()),now:clock });
  assert.equal(report.mode,'API'); assert.equal(report.asOf,'2026-01-15T09:00+09:00');
  assert.equal(JSON.parse(await fs.readFile(path.join(dir,'weather.json'))).temperature,12.5);
  assert.match(await fs.readFile(path.join(dir,'weather-dashboard.html'),'utf8'),/12.5 °C/);
});
test('DEMO는 API를 부르지 않고 합성 출처를 표시한다; 0은 유효하다', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(),'api-lab-'));
  t.after(()=>fs.rm(dir,{recursive:true,force:true}));
  const r = await run({fixture:path.join(__dirname,'fixtures/weather-zero-synthetic.json'),outputDir:dir,fetchImpl:()=>{throw new Error('API 호출 금지');},now:clock});
  assert.equal(r.temperature,0); assert.equal(r.humidity,0); assert.equal(r.weatherCode,0);
  assert.equal(r.mode,'DEMO'); assert.match(r.provenance,/synthetic/);
  assert.match(await fs.readFile(path.join(dir,'weather-dashboard.html'),'utf8'),/실제 관측값이 아닙니다/);
});
test('HTTP/JSON/누락/숫자문자열/시간/단위 오류가 기존 정상 결과를 보존한다', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(),'api-lab-'));
  t.after(()=>fs.rm(dir,{recursive:true,force:true}));
  await run({fixture,outputDir:dir,now:clock});
  const files=['weather.json','weather-dashboard.html'];
  const before=await Promise.all(files.map(f=>fs.readFile(path.join(dir,f),'utf8')));
  const missing=await payload(); delete missing.current.relative_humidity_2m;
  const badNumber=await payload(); badNumber.current.temperature_2m='0';
  const badDate=await payload(); badDate.current.time='2026-02-30T09:00';
  const badUnit=await payload(); badUnit.current_units.temperature_2m='°F';
  const methods=[async()=>({ok:false,status:429}),async()=>({ok:true,json:async()=>{throw new SyntaxError('malformed JSON');}}),mock(missing),mock(badNumber),mock(badDate),mock(badUnit),async()=>{throw new Error('network failed');}];
  for(const fetchImpl of methods){
    await assert.rejects(run({outputDir:dir,fetchImpl,now:clock}));
    assert.deepEqual(await Promise.all(files.map(f=>fs.readFile(path.join(dir,f),'utf8'))),before);
  }
});
test('본문 로딩 중 시간초과도 취소하고 기존 결과를 보존한다',async t=>{
  const dir=await fs.mkdtemp(path.join(os.tmpdir(),'api-lab-'));
  t.after(()=>fs.rm(dir,{recursive:true,force:true}));
  await run({fixture,outputDir:dir,now:clock});
  const before=await fs.readFile(path.join(dir,'weather.json'),'utf8');
  const fetchImpl=async(_, {signal})=>({ok:true,json:()=>new Promise((resolve,reject)=>signal.addEventListener('abort',()=>reject(new Error('aborted')),{once:true}))});
  await assert.rejects(run({outputDir:dir,fetchImpl,timeoutMs:20}),/시간 초과/);
  assert.equal(await fs.readFile(path.join(dir,'weather.json'),'utf8'),before);
});
test('schema 및 HTML 주입 검사',async()=>{
  const bad=await payload(); bad.current.temperature_2m=null; assert.throws(()=>validate(bad));
  const r={...validate(await payload()),mode:'DEMO',provenance:'<img src=x onerror=alert(1)>',generatedAt:'test'};
  const html=render(r); assert.ok(!html.includes('<img src=x')); assert.ok(html.includes('&lt;img'));
});
