'use strict';
// Node 22+; no dependencies, no AI calls. Fixture mode is always explicit.
const fs = require('node:fs/promises');
const path = require('node:path');
const URL_WEATHER = 'https://api.open-meteo.com/v1/forecast?latitude=37.5665&longitude=126.9780&current=temperature_2m,relative_humidity_2m,weather_code&timezone=Asia%2FSeoul&forecast_days=1';
const WMO = new Set([0,1,2,3,45,48,51,53,55,56,57,61,63,65,66,67,71,73,75,77,80,81,82,85,86,95,96,99]);
function validate(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('JSON 객체가 필요합니다.');
  const c = data.current, u = data.current_units;
  if (!c || !u) throw new Error('current 또는 current_units가 없습니다.');
  if (data.timezone !== 'Asia/Seoul' || data.utc_offset_seconds !== 32400) throw new Error('서울 시간대(UTC+09:00)가 아닙니다.');
  if (typeof c.time !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2})?$/.test(c.time)) throw new Error('기준 시각 형식이 잘못되었습니다.');
  const utc = new Date(c.time + '+09:00');
  if (!Number.isFinite(utc.getTime()) || new Date(utc.getTime()+32400000).toISOString().slice(0,c.time.length) !== c.time) throw new Error('기준 시각이 유효하지 않습니다.');
  if (u.time !== 'iso8601' || u.temperature_2m !== '°C' || u.relative_humidity_2m !== '%' || u.weather_code !== 'wmo code') throw new Error('응답 단위가 예상과 다릅니다.');
  if (!Number.isFinite(c.temperature_2m)) throw new Error('기온은 유한한 숫자여야 합니다.');
  if (!Number.isFinite(c.relative_humidity_2m) || c.relative_humidity_2m < 0 || c.relative_humidity_2m > 100) throw new Error('습도는 0~100 숫자여야 합니다.');
  if (!WMO.has(c.weather_code)) throw new Error('날씨 코드가 유효하지 않습니다.');
  return { asOf: c.time + '+09:00', timezone: data.timezone, temperature: c.temperature_2m, humidity: c.relative_humidity_2m, weatherCode: c.weather_code, units: { temperature: u.temperature_2m, humidity: u.relative_humidity_2m, weatherCode: u.weather_code } };
}
function escapeHTML(value) { return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function render(report) {
  const e = escapeHTML;
  return `<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>서울 날씨 대시보드</title><style>body{font:18px/1.65 system-ui;max-width:780px;margin:64px auto;padding:0 24px;background:#faf9f6;color:#20312b}h1{font-size:2rem}.badge{border:1px solid;padding:12px;border-radius:8px}dl{display:grid;grid-template-columns:1fr 1fr;background:white;padding:24px;border-radius:12px}dd{margin:0;font-weight:700}.note{font-size:14px}</style><main><p class="badge">${e(report.mode)} · ${e(report.provenance)}</p><h1>서울 날씨 대시보드</h1><p>날씨 기준: ${e(report.asOf)} (${e(report.timezone)})</p><dl><dt>기온</dt><dd>${e(report.temperature)} ${e(report.units.temperature)}</dd><dt>습도</dt><dd>${e(report.humidity)} ${e(report.units.humidity)}</dd><dt>WMO 날씨 코드</dt><dd>${e(report.weatherCode)}</dd></dl><p class="note">파일 생성: ${e(report.generatedAt)} · 자동 새로고침 없음. 다시 실행 후 이 화면을 새로고침하세요.</p><p class="note">${report.mode === 'DEMO' ? '합성 연습 데이터이며 실제 관측값이 아닙니다.' : 'Open-Meteo의 현재값은 기상 모델 기반 데이터입니다. 관측소 실측으로 해석하지 마세요.'}</p><p class="note">데이터 API: <a href="https://open-meteo.com/">Open-Meteo</a> · <a href="https://creativecommons.org/licenses/by/4.0/">CC BY 4.0</a>. 선택 필드 추출 및 화면 변환.</p></main></html>\n`;
}
async function fetchWeather(fetchImpl, timeoutMs) {
  const abort = new AbortController();
  const timer = setTimeout(() => abort.abort(), timeoutMs);
  try {
    const response = await fetchImpl(URL_WEATHER, { signal: abort.signal });
    if (!response.ok) throw new Error(`HTTP ${response.status}: API 요청 실패`);
    return await response.json(); // Timeout also covers body consumption.
  } catch (error) {
    if (abort.signal.aborted) throw new Error(`${timeoutMs}ms 시간 초과: 다시 실행하기 전 연결을 확인하세요.`);
    throw error;
  } finally { clearTimeout(timer); }
}
async function run({fixture, outputDir, fetchImpl = globalThis.fetch, timeoutMs = 10000, now = () => new Date()} = {}) {
  if (!outputDir) throw new Error('출력 폴더가 필요합니다.');
  let data;
  if (fixture) {
    data = JSON.parse(await fs.readFile(fixture, 'utf8'));
    if (data._fixture?.kind !== 'synthetic') throw new Error('합성 fixture 표시가 없습니다.');
  } else { data = await fetchWeather(fetchImpl, timeoutMs); }
  // Validate everything before touching the last good files.
  const report = { ...validate(data), mode: fixture ? 'DEMO' : 'API', provenance: fixture ? `synthetic fixture: ${path.basename(fixture)}` : 'Open-Meteo API 응답', generatedAt: now().toISOString(), sourceUrl: URL_WEATHER };
  const json = JSON.stringify(report, null, 2) + '\n', html = render(report);
  await fs.mkdir(outputDir, { recursive: true });
  await fs.writeFile(path.join(outputDir, 'weather.json'), json);
  await fs.writeFile(path.join(outputDir, 'weather-dashboard.html'), html);
  return report;
}
function parseArgs(args) {
  const result = { outputDir: 'output/weather' };
  for (let i=0; i<args.length; i++) {
    const key = {'--fixture':'fixture','--output':'outputDir'}[args[i]];
    if (!key || !args[i+1] || args[i+1].startsWith('--')) throw new Error('사용법: node weather.cjs [--fixture 파일.json] [--output 출력폴더]');
    result[key] = args[++i];
  }
  return result;
}
if (require.main === module) {
  Promise.resolve().then(() => run(parseArgs(process.argv.slice(2)))).then(report => console.log(`${report.mode}: ${report.temperature} °C · ${report.asOf}`)).catch(error => { console.error(`실패: ${error.message}\nAPI/JSON 오류가 나면 기존 결과를 보존합니다. DEMO로 자동 전환하지 않습니다.`); process.exitCode = 1; });
}
module.exports = { run, validate, render, escapeHTML, fetchWeather, URL_WEATHER };
