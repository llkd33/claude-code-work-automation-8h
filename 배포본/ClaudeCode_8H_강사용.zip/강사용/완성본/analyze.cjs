// 강사용 합류본. Node 표준 기능만 사용하고 AI/API를 호출하지 않습니다.
const fs = require('node:fs');
const path = require('node:path');
const HEADERS = ['id', 'date', 'department', 'item', 'quantity', 'unit_price'];
function parseCsv(text) {
  text = text.replace(/^\uFEFF/, '');
  const rows = []; let row = [], field = '', quoted = false, closed = false, active = false;
  function cell() { row.push(field); field = ''; closed = false; }
  function record() { cell(); rows.push(row); row = []; active = false; }
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"' && text[i + 1] === '"') { field += '"'; i++; }
      else if (c === '"') { quoted = false; closed = true; }
      else field += c;
      active = true; continue;
    }
    if (c === ',') { cell(); active = true; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; record(); }
    else if (c === '"') {
      if (field.length || closed) throw new Error('CSV 따옴표 위치가 잘못되었습니다.');
      quoted = true; active = true;
    } else {
      if (closed) throw new Error('CSV 닫힌 따옴표 뒤에 문자가 있습니다.');
      field += c; active = true;
    }
  }
  if (quoted) throw new Error('CSV 따옴표가 닫히지 않았습니다.');
  if (active || row.length || field) record();
  return rows;
}
function csvText(rows) {
  return '\uFEFF' + rows.map(row => row.map(v => {
    const s = String(v); return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }).join(',')).join('\r\n') + '\r\n';
}
function html(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function inside(base, candidate) {
  const r = path.relative(base, candidate); return r && !r.startsWith('..' + path.sep) && r !== '..' && !path.isAbsolute(r);
}
function dateValid(s) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const [y,m,d] = s.split('-').map(Number);
  if (y < 1000 || m < 1 || m > 12 || d < 1) return false;
  const n = new Date(Date.UTC(y,m-1,d));
  return n.getUTCFullYear() === y && n.getUTCMonth() === m-1 && n.getUTCDate() === d;
}
function analyze(input, output) {
  const raw = parseCsv(fs.readFileSync(input, 'utf8'));
  if (!raw.length || JSON.stringify(raw[0].map(x => x.trim())) !== JSON.stringify(HEADERS)) throw new Error('CSV 헤더가 예상한 6개 열과 다릅니다.');
  const data = raw.slice(1), kept = [], excluded = [], seen = new Set(), ids = new Set(), byDepartment = Object.create(null);
  const summary = {inputRows:data.length, validRows:0, duplicateRows:0, errorRows:0, totalAmount:0, byDepartment};
  for (let i = 0; i < data.length; i++) {
    const fields = data[i].map(x => x.trim()), key = JSON.stringify(fields);
    const recordedFields = Array.from({length:6}, (_,index) => fields[index] || '');
    const rawFields = JSON.stringify(fields);
    if (seen.has(key)) { summary.duplicateRows++; excluded.push([i+1,'중복','완전히 같은 행',...recordedFields,rawFields]); continue; }
    seen.add(key);
    const [id,date,department,item,qs,ps] = fields;
    const reasons = [];
    if (fields.length !== 6) reasons.push('열 개수 오류');
    if (![id,date,department,item].every(x => x)) reasons.push('필수값 누락');
    if (!dateValid(date || '')) reasons.push('유효하지 않은 날짜');
    const qty = Number(qs), price = Number(ps);
    if (!/^\d+$/.test(qs || '') || !Number.isSafeInteger(qty) || qty <= 0) reasons.push('수량은 양의 정수');
    if (!/^\d+$/.test(ps || '') || !Number.isSafeInteger(price) || price < 0) reasons.push('단가는 0 이상 정수');
    if (id && ids.has(id)) reasons.push('같은 id의 다른 값');
    const amount = qty * price;
    if (!reasons.length && (!Number.isSafeInteger(amount) || !Number.isSafeInteger(summary.totalAmount + amount))) reasons.push('정수 계산 범위 초과');
    if (reasons.length) { summary.errorRows++; excluded.push([i+1,'오류',reasons.join('; '),...recordedFields,rawFields]); continue; }
    ids.add(id); kept.push([...fields,amount]); summary.validRows++; summary.totalAmount += amount;
    byDepartment[department] = (byDepartment[department] || 0) + amount;
  }
  const bySum = Object.values(byDepartment).reduce((a,b) => a+b,0);
  if (summary.inputRows !== summary.validRows + summary.duplicateRows + summary.errorRows || bySum !== summary.totalAmount) throw new Error('내부 검증 실패');
  const tmpl = fs.readFileSync(path.resolve('templates/email_template.txt'),'utf8');
  // 보고서와 메일은 디스크에 저장된 동일 집계 JSON을 사용합니다.
  fs.mkdirSync(output,{recursive:true});
  fs.writeFileSync(path.join(output,'summary.json'),JSON.stringify(summary,null,2)+'\n');
  const reportData = JSON.parse(fs.readFileSync(path.join(output,'summary.json'),'utf8'));
  const email = tmpl.replace(/\{\{(\w+)\}\}/g, (whole,key) => {
    if (!['validRows','totalAmount','duplicateRows','errorRows'].includes(key)) throw new Error('알 수 없는 이메일 변수: ' + key);
    return String(reportData[key]);
  });
  const report = `<!DOCTYPE html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>주간 비용 보고서</title><style>body{max-width:850px;margin:40px auto;padding:0 20px;font-family:sans-serif;line-height:1.7}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:10px;text-align:left}strong{color:#a73026}</style><h1>주간 비용 보고서</h1><p>가상 수업 데이터 · 원본: ${html(path.basename(input))}</p><p>입력 ${reportData.inputRows}행 / 유효 ${reportData.validRows} / 중복 ${reportData.duplicateRows} / 오류 ${reportData.errorRows}</p><p>총액 <strong>${reportData.totalAmount.toLocaleString('ko-KR')}원</strong></p><h2>부서별 합계</h2><table><tr><th>부서</th><th>금액</th></tr>${Object.entries(reportData.byDepartment).map(([k,v])=>`<tr><td>${html(k)}</td><td>${v.toLocaleString('ko-KR')}원</td></tr>`).join('')}</table><h2>제외 목록</h2><table><tr><th>데이터 행 번호</th><th>구분</th><th>사유</th></tr>${excluded.map(r=>`<tr><td>${r[0]}</td><td>${html(r[1])}</td><td>${html(r[2])}</td></tr>`).join('')}</table><p>검증: 입력 행=유효+중복+오류, 총액=부서별 합계 · 통과</p></html>`;
  fs.mkdirSync(output,{recursive:true});
  fs.writeFileSync(path.join(output,'cleaned.csv'),csvText([HEADERS.concat('amount'),...kept]));
  fs.writeFileSync(path.join(output,'excluded.csv'),csvText([['data_row','type','reason',...HEADERS,'raw_fields_json'],...excluded]));
  fs.writeFileSync(path.join(output,'summary.json'),JSON.stringify(summary,null,2)+'\n');
  fs.writeFileSync(path.join(output,'report.html'),report);
  fs.writeFileSync(path.join(output,'email_draft.txt'),email);
  return summary;
}
if (require.main === module) {
  try {
    const [inputArg,outputArg] = process.argv.slice(2);
    if (!inputArg || !outputArg) throw new Error('사용법: node scripts/analyze.cjs <입력 CSV> <output 안 결과 폴더>');
    const input = path.resolve(inputArg), output = path.resolve(outputArg);
    if (!inside(path.resolve('input'),input) || !inside(path.resolve('output'),output)) throw new Error('실습 폴더 루트에서 input 파일과 output 안 하위 결과 폴더를 지정하세요.');
    const summary = analyze(input,output);
    console.log(JSON.stringify({output:outputArg,...summary},null,2));
  } catch (e) { console.error('실행 실패: '+e.message); process.exitCode=1; }
}
module.exports = {parseCsv,csvText,analyze,dateValid};
