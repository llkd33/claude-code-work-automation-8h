// 수강생 코드의 대체 합류본. AI/API 호출 없이 저장한 JSON으로만 보고서를 만듭니다.
const fs=require('node:fs'),path=require('node:path');
const escapeHTML=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function validate(s){
 const keys=['inputRows','validRows','duplicateRows','errorRows','totalAmount'];
 for(const k of keys)if(!Number.isSafeInteger(s[k])||s[k]<0)throw Error('정상 정수가 필요합니다: '+k);
 if(s.inputRows!==s.validRows+s.duplicateRows+s.errorRows)throw Error('행 수 등식 오류');
 if(!s.byDepartment||Array.isArray(s.byDepartment)||typeof s.byDepartment!=='object')throw Error('부서별 합계 누락');
 const totals=Object.values(s.byDepartment);if(!totals.length||totals.some(n=>!Number.isSafeInteger(n)||n<0)||totals.reduce((a,b)=>a+b,0)!==s.totalAmount)throw Error('총액/부서 합계 오류');
 return s;
}
function render(s,{sheetURL='',queriedAt='조회 시각 미기록'}={}){
 validate(s);if(sheetURL&&!/^https:\/\/docs\.google\.com\/spreadsheets\/d\/[A-Za-z0-9_-]+(?:[/?#].*)?$/.test(sheetURL))throw Error('교육용 Sheets URL 형식 오류');
 const fmt=n=>n.toLocaleString('ko-KR');
 const cards=[['비용 건수',fmt(s.inputRows)+'건'],['총액',fmt(s.totalAmount)+'원'],['부서',Object.keys(s.byDepartment).length+'개'],['보고서 상태','조회 시점 스냅샷']];
 // KPI 요약의 숫자 0은 원본 행 검사 증거가 아니다. 이 실행기는 합계만 검사한다.
 const quality='<p role="note"><b>원본 품질 검사 미실행</b> · 이 도구는 저장된 요약의 합계와 행 수 등식만 검사합니다. 중복·빈 값·누락 여부는 별도 원본 검사로 확인하세요.</p>';
 return '<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>주간 비용 보고서</title><style>body{font-family:system-ui,sans-serif;background:#fafafa;color:#161616;max-width:980px;margin:64px auto;padding:24px}h1{font-size:36px}.cards{display:grid;grid-template-columns:repeat(2,1fr);gap:16px}.card,table{background:white;border:1px solid #e7e7eb;border-radius:12px}.card{padding:24px}.card small{display:block;color:#6e7585}.card b{display:block;font-size:26px;margin-top:12px;color:#d72d48}table{width:100%;margin-top:32px;border-collapse:collapse}th,td{text-align:left;padding:16px;border-bottom:1px solid #eee}footer{color:#6e7585;margin-top:32px;line-height:1.7}@media(max-width:480px){body{margin:8px auto}.cards{grid-template-columns:1fr}}</style><main><p>WEEKLY EXPENSE REPORT</p><h1>주간 비용 보고서</h1><div class="cards">'+cards.map(([a,b])=>'<div class="card"><small>'+escapeHTML(a)+'</small><b>'+escapeHTML(b)+'</b></div>').join('')+'</div>'+quality+'<table><thead><tr><th>부서</th><th>비용 합계</th></tr></thead><tbody>'+Object.entries(s.byDepartment).map(([k,v])=>'<tr><td>'+escapeHTML(k)+'</td><td>'+fmt(v)+'원</td></tr>').join('')+'</tbody></table><footer>조회 시각: '+escapeHTML(queriedAt)+'<br>시트 변경은 이 파일에 자동 반영되지 않습니다. 최신 숫자를 다시 조회·저장한 뒤 재생성하세요.'+(sheetURL?'<br><a href="'+escapeHTML(sheetURL)+'" target="_blank" rel="noopener">교육용 Google Sheet 열기</a>':'')+'</footer></main></html>';
}
function main(){
 const dir=path.resolve('output/sample');const file=path.join(dir,'summary.json');
 const s=validate(JSON.parse(fs.readFileSync(file,'utf8')));
 const metaFile=path.join(dir,'snapshot-meta.json');const meta=fs.existsSync(metaFile)?JSON.parse(fs.readFileSync(metaFile,'utf8')):{};
 const html=render(s,meta);fs.writeFileSync(path.join(dir,'report.html'),html);console.log('보고서 생성: '+s.inputRows+'건 / '+s.totalAmount+'원 / output/sample/report.html');
}
module.exports={validate,render};if(require.main===module){try{main()}catch(e){console.error('실패: '+e.message);process.exitCode=1}}
