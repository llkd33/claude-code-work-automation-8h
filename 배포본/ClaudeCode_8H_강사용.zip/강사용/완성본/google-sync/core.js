/* Apps Script V8 + Node 공용. Google 호출은 adapter가 담당합니다. */
var GoogleSyncCore = (function () {
  const START = '[[AUTO_REPORT_START]]';
  const END = '[[AUTO_REPORT_END]]';
  function canonicalize(values) {
    if (!Array.isArray(values) || values.length < 2) throw Error('입력 데이터가 비었습니다. 기존 결과를 유지합니다.');
    const expected = ['id', 'team', 'amount', 'status'];
    if (!Array.isArray(values[0]) || expected.some((v, i) => values[0][i] !== v) || values[0].length !== 4) throw Error('머리글은 id/team/amount/status 4열이어야 합니다.');
    const ids = new Set();
    const rows = [];
    values.slice(1).forEach((cells, offset) => {
      if (!Array.isArray(cells) || cells.length !== 4) throw Error('열 수 오류: ' + (offset + 2));
      if (cells.every(v => v === '' || v === null)) return;
      const id = typeof cells[0] === 'string' ? cells[0].trim() : '';
      const team = typeof cells[1] === 'string' ? cells[1].trim() : '';
      const amount = cells[2];
      const status = typeof cells[3] === 'string' ? cells[3].trim() : '';
      if (!id || !team || id.length > 80 || team.length > 80 || /[\r\n]/.test(id + team)) throw Error('id/team 값 오류: ' + (offset + 2));
      if (ids.has(id)) throw Error('중복 id: ' + id);
      if (typeof amount !== 'number' || !Number.isSafeInteger(amount) || amount < 0) throw Error('amount는 0 이상 정수 숫자 셀이어야 합니다: ' + (offset + 2));
      if (!['진행', '완료'].includes(status)) throw Error('status는 진행/완료여야 합니다: ' + (offset + 2));
      ids.add(id);
      rows.push({ id, team, amount, status });
    });
    if (!rows.length) throw Error('입력 데이터가 비었습니다. 기존 결과를 유지합니다.');
    rows.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
    const total = rows.reduce((n, r) => n + r.amount, 0);
    if (!Number.isSafeInteger(total)) throw Error('합계가 안전한 정수 범위를 넘었습니다.');
    return rows;
  }
  function reportSlot(paragraphs) {
    const starts = [], ends = [];
    paragraphs.forEach((text, i) => { if (text === START) starts.push(i); if (text === END) ends.push(i); });
    if (starts.length !== 1 || ends.length !== 1 || ends[0] !== starts[0] + 2 || typeof paragraphs[starts[0] + 1] !== 'string') throw Error('Docs 첫 탭에 시작 표식/본문 1문단/끝 표식이 필요합니다.');
    return starts[0] + 1;
  }
  function summary(rows) {
    return { count: rows.length, total: rows.reduce((n, r) => n + r.amount, 0), completed: rows.filter(r => r.status === '완료').length };
  }
  function run(adapter) {
    if (!adapter.acquire()) return { status: 'busy' };
    try {
      const rows = canonicalize(adapter.readValues());
      const hash = adapter.hash(JSON.stringify(rows));
      const previous = adapter.readHash();
      if (previous === hash) return { status: 'unchanged', hash, summary: summary(rows) };
      const s = summary(rows);
      const stamp = adapter.now();
      const first = !previous;
      // 모든 사전 점검을 출력 변경 전에 실행합니다.
      adapter.prepare();
      adapter.writeDashboard([
        ['CLAUDE_LAB_DASHBOARD', '값'], ['업데이트 시각', stamp],
        ['건수', s.count], ['총액(원)', s.total], ['완료', s.completed],
        ['진행', s.count - s.completed], ['내용 해시', hash], ['처리', first ? '첫 기준 생성' : '변경 반영']
      ]);
      const text = '업무 데이터 보고서\n확인 시각: ' + stamp + '\n건수: ' + s.count + '\n총액(원): ' + s.total + '\n완료: ' + s.completed + '\n진행: ' + (s.count - s.completed) + '\n처리: ' + (first ? '첫 기준 생성' : '변경 반영');
      adapter.writeReport(text);
      adapter.finish();
      adapter.saveHash(hash); // Sheets flush + Docs save 이후에만 성공으로 기록합니다.
      return { status: first ? 'initialized' : 'changed', hash, summary: s };
    } finally { adapter.release(); }
  }
  return { START, END, canonicalize, reportSlot, summary, run };
}());
if (typeof module !== 'undefined') module.exports = GoogleSyncCore;
