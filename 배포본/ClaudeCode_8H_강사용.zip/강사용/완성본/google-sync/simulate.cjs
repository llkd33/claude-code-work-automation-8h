#!/usr/bin/env node
/* 로컬 모의 연결. Google 로그인/호출/스케줄은 수행하지 않습니다. */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const core = require('./core.js');
function atomicJson(file, value) {
  const temp = file + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(value, null, 2) + '\n');
  fs.renameSync(temp, file);
}
function simulate(input, output, failAt = '') {
  fs.mkdirSync(output, { recursive: true });
  const file = name => path.join(output, name);
  let descriptor, paragraphs, slot;
  return core.run({
    acquire() {
      try { descriptor = fs.openSync(file('sync.lock'), 'wx'); return true; }
      catch (e) { if (e.code === 'EEXIST') return false; throw e; }
    },
    release() { fs.closeSync(descriptor); fs.unlinkSync(file('sync.lock')); },
    readValues() { return JSON.parse(fs.readFileSync(input, 'utf8')); },
    hash(text) { return crypto.createHash('sha256').update(text).digest('hex'); },
    readHash() { return fs.existsSync(file('state.json')) ? JSON.parse(fs.readFileSync(file('state.json'), 'utf8')).hash : null; },
    now() { return '2026-10-07 09:30:00 [모의 시각]'; },
    prepare() {
      paragraphs = fs.existsSync(file('docs.json')) ? JSON.parse(fs.readFileSync(file('docs.json'), 'utf8')) : ['팀장이 작성한 소개: 이번 주 업무를 확인합니다.', core.START, '자동 보고서 자리', core.END, '직접 작성한 결론은 유지합니다.'];
      slot = core.reportSlot(paragraphs);
    },
    writeDashboard(values) { atomicJson(file('dashboard.json'), values); },
    writeReport(text) {
      if (failAt === 'docs') throw Error('모의 Docs 저장 실패');
      paragraphs[slot] = text;
      atomicJson(file('docs.json'), paragraphs);
    },
    finish() {
      if (failAt === 'finish') throw Error('모의 최종 저장 실패');
      fs.writeFileSync(file('report.md'), paragraphs.join('\n\n') + '\n');
    },
    saveHash(hash) { atomicJson(file('state.json'), { hash }); }
  });
}
if (require.main === module) {
  const [input, output, option] = process.argv.slice(2);
  if (!input || !output || (option && !['--fail-at=docs', '--fail-at=finish'].includes(option))) {
    console.error('사용법: node simulate.cjs 입력.json 출력폴더 [--fail-at=docs|--fail-at=finish]');
    process.exitCode = 2;
  } else {
    try { console.log(JSON.stringify(simulate(input, output, (option || '').split('=')[1]), null, 2)); }
    catch (e) { console.error(e.message); process.exitCode = 1; }
  }
}
module.exports = { simulate };
