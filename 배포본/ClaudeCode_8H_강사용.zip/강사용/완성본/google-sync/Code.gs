/* Apps Script 편집기에 core.js 내용을 Core.gs로 함께 붙여 넣으세요. */
const CONFIG = {
  SPREADSHEET_ID: '여기에_실습_스프레드시트_ID',
  DOC_ID: '여기에_실습_구글_문서_ID',
  SOURCE_SHEET: 'Data',
  DASHBOARD_SHEET: 'Dashboard',
  TIMEZONE: 'Asia/Seoul',
  HOUR: 9
};

function checkConfig() {
  if (!CONFIG.SPREADSHEET_ID || !CONFIG.DOC_ID || /여기에/.test(CONFIG.SPREADSHEET_ID + CONFIG.DOC_ID)) throw Error('실습 파일 ID를 설정하세요.');
  if (CONFIG.SOURCE_SHEET === CONFIG.DASHBOARD_SHEET) throw Error('입력/출력 탭 이름을 다르게 설정하세요.');
  if (!Number.isInteger(CONFIG.HOUR) || CONFIG.HOUR < 0 || CONFIG.HOUR > 23) throw Error('HOUR는 0~23 정수입니다.');
}

function syncDaily() {
  checkConfig();
  const lock = LockService.getScriptLock();
  const props = PropertiesService.getScriptProperties();
  const key = 'v1:' + CONFIG.SPREADSHEET_ID + ':' + CONFIG.SOURCE_SHEET + ':' + CONFIG.DASHBOARD_SHEET + ':' + CONFIG.DOC_ID;
  let spreadsheet, dashboard, doc, reportParagraph;
  const result = GoogleSyncCore.run({
    acquire: () => lock.tryLock(5000),
    release: () => lock.releaseLock(),
    readValues: () => {
      spreadsheet = SpreadsheetApp.openById(CONFIG.SPREADSHEET_ID);
      const source = spreadsheet.getSheetByName(CONFIG.SOURCE_SHEET);
      if (!source) throw Error('Data 입력 탭을 찾을 수 없습니다.');
      if (source.getLastRow() > 1001) throw Error('이 교육 예제는 최대 1000건입니다.');
      return source.getDataRange().getValues();
    },
    hash: text => Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, text, Utilities.Charset.UTF_8).map(n => ('0' + ((n + 256) % 256).toString(16)).slice(-2)).join(''),
    readHash: () => props.getProperty(key),
    now: () => Utilities.formatDate(new Date(), CONFIG.TIMEZONE, 'yyyy-MM-dd HH:mm:ss'),
    prepare: () => {
      // 첫 문서 탭만 사용. 다른 탭/소개/결론/서식은 변경하지 않습니다.
      doc = DocumentApp.openById(CONFIG.DOC_ID);
      const body = doc.getTabs()[0].asDocumentTab().getBody();
      const texts = [];
      for (let i = 0; i < body.getNumChildren(); i++) {
        const child = body.getChild(i);
        texts.push(child.getType() === DocumentApp.ElementType.PARAGRAPH ? child.asParagraph().getText() : null);
      }
      reportParagraph = body.getChild(GoogleSyncCore.reportSlot(texts)).asParagraph();
      dashboard = spreadsheet.getSheetByName(CONFIG.DASHBOARD_SHEET);
      if (dashboard && dashboard.getLastRow() > 0 && dashboard.getRange('A1').getValue() !== 'CLAUDE_LAB_DASHBOARD') throw Error('Dashboard가 비어 있지 않습니다. 다른 전용 탭 이름을 설정하세요.');
    },
    writeDashboard: values => {
      if (!dashboard) dashboard = spreadsheet.insertSheet(CONFIG.DASHBOARD_SHEET);
      dashboard.getRange(1, 1, values.length, 2).setValues(values);
    },
    writeReport: text => reportParagraph.setText(text),
    finish: () => { SpreadsheetApp.flush(); doc.saveAndClose(); },
    saveHash: hash => props.setProperty(key, hash)
  });
  console.log(JSON.stringify(result));
  return result;
}

function installDailyTrigger() {
  checkConfig();
  // 수동 실행 3회 검증 후 설치하세요. 다른 사용자 트리거는 조회되지 않습니다.
  const lock = LockService.getScriptLock();
  lock.waitLock(5000);
  try {
    const matching = ScriptApp.getProjectTriggers().filter(t => t.getHandlerFunction() === 'syncDaily' && t.getEventType() === ScriptApp.EventType.CLOCK);
    if (matching.length) {
      matching.slice(1).forEach(t => ScriptApp.deleteTrigger(t));
      console.log('현재 사용자 기준 기존 syncDaily 시계 트리거 1개 유지. 시간 변경은 삭제 후 재설치하세요.');
      return;
    }
    ScriptApp.newTrigger('syncDaily').timeBased().atHour(CONFIG.HOUR).everyDays(1).inTimezone(CONFIG.TIMEZONE).create();
    console.log('매일 실행 설치 완료. 지정 시각 정각은 보장되지 않습니다.');
  } finally { lock.releaseLock(); }
}

function removeDailyTrigger() {
  const lock = LockService.getScriptLock();
  lock.waitLock(5000);
  try {
    ScriptApp.getProjectTriggers().filter(t => t.getHandlerFunction() === 'syncDaily' && t.getEventType() === ScriptApp.EventType.CLOCK).forEach(t => ScriptApp.deleteTrigger(t));
    console.log('현재 사용자가 만든 syncDaily 시계 트리거만 삭제했습니다.');
  } finally { lock.releaseLock(); }
}
