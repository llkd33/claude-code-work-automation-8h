/* 외부 계정 없이 실행: Node 파일 파이프라인 + 실제 Code.gs를 Google 서비스 모형으로 검증. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const solution = path.join(root, '강사용/완성본/google-sync');
const fixtures = path.join(root, '실습자료/claude-work-lab/input/sheets-snapshots');
const { simulate } = require(path.join(solution, 'simulate.cjs'));
const core = require(path.join(solution, 'core.js'));
const sourceHashes = () => fs.readdirSync(fixtures).sort().map(n => [n, crypto.createHash('sha256').update(fs.readFileSync(path.join(fixtures, n))).digest('hex')]);
const sourceBefore = sourceHashes();
const output = path.join(__dirname, 'google-sync-verification');
fs.rmSync(output, { recursive: true, force: true });
const input = n => path.join(fixtures, n + '.json');
const initial = JSON.parse(fs.readFileSync(input('01-initial')));
const changed = JSON.parse(fs.readFileSync(input('03-changed')));
const result = [];
function check(name, fn) { fn(); result.push(name); }
function hashOutputs() {
  return ['dashboard.json', 'docs.json', 'report.md', 'state.json'].map(n => crypto.createHash('sha256').update(fs.readFileSync(path.join(output, n))).digest('hex'));
}
check('first-run creates baseline 3 / 35000 / completed 2', () => {
  const r = simulate(input('01-initial'), output);
  assert.equal(r.status, 'initialized');
  assert.deepEqual(r.summary, { count: 3, total: 35000, completed: 2 });
});
check('same reordered data produces no writes', () => {
  const before = hashOutputs();
  assert.equal(simulate(input('02-same'), output).status, 'unchanged');
  assert.deepEqual(hashOutputs(), before);
});
check('malformed stops without changing outputs or checkpoint', () => {
  const before = hashOutputs();
  assert.throws(() => simulate(input('04-malformed'), output), /amount/);
  assert.deepEqual(hashOutputs(), before);
  assert.equal(fs.existsSync(path.join(output, 'sync.lock')), false);
});
check('Docs failure leaves old hash, next run retries changed data', () => {
  const before = fs.readFileSync(path.join(output, 'state.json'), 'utf8');
  assert.throws(() => simulate(input('03-changed'), output, 'docs'), /Docs/);
  assert.equal(fs.readFileSync(path.join(output, 'state.json'), 'utf8'), before);
  const r = simulate(input('03-changed'), output);
  assert.equal(r.status, 'changed');
  assert.deepEqual(r.summary, { count: 4, total: 48000, completed: 3 });
});
check('preserves manual introduction/conclusion and never appends duplicates', () => {
  const paragraphs = JSON.parse(fs.readFileSync(path.join(output, 'docs.json')));
  assert.equal(paragraphs.length, 5);
  assert.match(paragraphs[0], /팀장이 작성한 소개/);
  assert.match(paragraphs[4], /직접 작성한 결론/);
  const before = hashOutputs();
  assert.equal(simulate(input('03-changed'), output).status, 'unchanged');
  assert.deepEqual(hashOutputs(), before);
});
check('lock blocks overlap', () => {
  fs.writeFileSync(path.join(output, 'sync.lock'), 'another runner');
  const before = hashOutputs();
  assert.equal(simulate(input('01-initial'), output).status, 'busy');
  assert.deepEqual(hashOutputs(), before);
  fs.unlinkSync(path.join(output, 'sync.lock'));
});
check('empty, duplicated ids, blank amount, extra columns, unknown status rejected', () => {
  const header = initial[0];
  for (const rows of [[], [header], [header, ['', '', '', '']], [header, initial[1], initial[1]], [header, ['x', '영업', '', '완료']], [header, ['x', '영업', 1, '대기']], [header, ['x', '영업', 1, '완료', '추가']], [header, ['x', '영업', -1, '완료']]]) assert.throws(() => core.canonicalize(rows));
});
check('invalid markers refused; valid marker target is one paragraph', () => {
  assert.equal(core.reportSlot(['intro', core.START, 'body', core.END, 'tail']), 2);
  for (const p of [[core.START, core.END], [core.START, 'one', 'two', core.END], [core.START, 'one', core.END, core.START], ['intro'], [core.START, null, core.END]]) assert.throws(() => core.reportSlot(p));
});

// Code.gs 실제 함수 호출: 서비스 구현 자체는 모형이므로 Google 실호출 검증으로 표현하지 않습니다.
let values = initial, locked = false, failSave = false, dashboard = null, savedDocs = 0;
let paragraphs = ['강사 수동 소개', core.START, '자리', core.END, '강사 수동 결론'];
const props = new Map();
const calls = [];
const scriptTriggers = [
  { name: 'unrelated', event: 'CLOCK' },
  { name: 'syncDaily', event: 'EDIT' }
];
const wrapTrigger = t => ({ getHandlerFunction: () => t.name, getEventType: () => t.event, raw: t });
const lock = {
  tryLock() { if (locked) return false; locked = true; return true; },
  waitLock() { if (locked) throw Error('lock timeout'); locked = true; },
  releaseLock() { assert.equal(locked, true); locked = false; }
};
const dashboardSheet = { getLastRow: () => dashboard ? dashboard.length : 0, getRange(...args) {
  if (args[0] === 'A1') return { getValue: () => dashboard?.[0]?.[0] };
  return { setValues(v) { dashboard = v; calls.push('dashboard'); } };
}};
const spreadsheet = {
  getSheetByName(name) { if (name === 'Data') return { getLastRow: () => values.length, getDataRange: () => ({ getValues: () => values }) }; if (name === 'Dashboard') return dashboard ? dashboardSheet : null; return null; },
  insertSheet(name) { assert.equal(name, 'Dashboard'); return dashboardSheet; }
};
const context = vm.createContext({
  console: { log() {} },
  LockService: { getScriptLock: () => lock },
  PropertiesService: { getScriptProperties: () => ({ getProperty: k => props.get(k) || null, setProperty(k, v) { props.set(k, v); calls.push('checkpoint'); } }) },
  SpreadsheetApp: { openById: () => spreadsheet, flush() { calls.push('flush'); } },
  Utilities: { DigestAlgorithm: { SHA_256: 'sha256' }, Charset: { UTF_8: 'utf8' }, computeDigest: (algorithm, text) => Array.from(crypto.createHash(algorithm).update(text).digest()), formatDate: () => '2026-10-07 09:30:00' },
  DocumentApp: {
    ElementType: { PARAGRAPH: 'PARAGRAPH' },
    openById() {
      const body = { getNumChildren: () => paragraphs.length, getChild: i => ({ getType: () => 'PARAGRAPH', asParagraph: () => ({ getText: () => paragraphs[i], setText(text) { paragraphs[i] = text; calls.push('docs'); } }) }) };
      return { getTabs: () => [{ asDocumentTab: () => ({ getBody: () => body }) }], saveAndClose() { if (failSave) throw Error('save failed'); savedDocs++; calls.push('save'); } };
    }
  },
  ScriptApp: {
    EventType: { CLOCK: 'CLOCK' },
    getProjectTriggers: () => scriptTriggers.map(wrapTrigger),
    deleteTrigger(t) { scriptTriggers.splice(scriptTriggers.indexOf(t.raw), 1); },
    newTrigger(name) {
      const builder = { timeBased() { return this; }, atHour(v) { assert.equal(v, 9); return this; }, everyDays(v) { assert.equal(v, 1); return this; }, inTimezone(v) { assert.equal(v, 'Asia/Seoul'); return this; }, create() { scriptTriggers.push({ name, event: 'CLOCK' }); return {}; } };
      return builder;
    }
  }
});
vm.runInContext(fs.readFileSync(path.join(solution, 'core.js'), 'utf8'), context);
vm.runInContext(fs.readFileSync(path.join(solution, 'Code.gs'), 'utf8').replace('여기에_실습_스프레드시트_ID', 'fixture-sheet').replace('여기에_실습_구글_문서_ID', 'fixture-doc'), context);
check('Apps Script first-run: checkpoint follows flush and document save', () => {
  assert.equal(context.syncDaily().status, 'initialized');
  assert.deepEqual(calls, ['dashboard', 'docs', 'flush', 'save', 'checkpoint']);
  assert.equal(dashboard[3][1], 35000);
});
check('Apps Script same data has no sink writes', () => {
  calls.length = 0;
  values = JSON.parse(fs.readFileSync(input('02-same')));
  assert.equal(context.syncDaily().status, 'unchanged');
  assert.deepEqual(calls, []);
});
check('Apps Script save failure retains checkpoint and releases lock; retry succeeds', () => {
  const before = Array.from(props.values())[0];
  values = changed;
  failSave = true;
  assert.throws(() => context.syncDaily(), /save failed/);
  assert.equal(Array.from(props.values())[0], before);
  assert.equal(locked, false);
  failSave = false;
  assert.equal(context.syncDaily().status, 'changed');
  assert.equal(paragraphs.length, 5);
  assert.equal(paragraphs[0], '강사 수동 소개');
  assert.equal(paragraphs[4], '강사 수동 결론');
});
check('Apps Script invalid Docs marker prevents dashboard update', () => {
  values = initial;
  const before = JSON.stringify(dashboard);
  paragraphs = ['소개', '표식 없음', '결론'];
  assert.throws(() => context.syncDaily(), /Docs/);
  assert.equal(JSON.stringify(dashboard), before);
});
check('Apps Script preserves unrelated and event triggers; duplicate clocks collapsed', () => {
  context.installDailyTrigger();
  context.installDailyTrigger();
  assert.equal(scriptTriggers.filter(t => t.name === 'syncDaily' && t.event === 'CLOCK').length, 1);
  scriptTriggers.push({ name: 'syncDaily', event: 'CLOCK' });
  context.installDailyTrigger();
  assert.equal(scriptTriggers.filter(t => t.name === 'syncDaily' && t.event === 'CLOCK').length, 1);
  context.removeDailyTrigger();
  assert.deepEqual(scriptTriggers.map(t => t.name + ':' + t.event), ['unrelated:CLOCK', 'syncDaily:EDIT']);
});
check('all input JSON and TSV fixture bytes preserved', () => assert.deepEqual(sourceHashes(), sourceBefore));
fs.writeFileSync(path.join(__dirname, 'google-sync-verification.json'), JSON.stringify({ passed: result.length, checks: result, liveGoogleExecution: false, liveScheduledExecution: false, savedDocsInMock: savedDocs }, null, 2) + '\n');
console.log(JSON.stringify({ passed: result.length, liveGoogleExecution: false, output }, null, 2));
