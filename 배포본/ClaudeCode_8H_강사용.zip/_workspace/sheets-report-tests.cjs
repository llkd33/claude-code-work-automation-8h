const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os'),{spawnSync}=require('node:child_process');
const root=path.resolve(__dirname,'..'),file=path.join(root,'강사용/완성본/report.cjs'),{validate,render}=require(file),contract=JSON.parse(fs.readFileSync(path.join(__dirname,'workbook-contract.json'),'utf8'));
const summary=x=>({inputRows:x.count,validRows:x.count,duplicateRows:0,errorRows:0,totalAmount:x.total,byDepartment:x.departmentTotals});
const s=summary(contract.afterAppend);assert.equal(validate(s).totalAmount,2363300);assert(render(s).includes('2,363,300원'));assert(render(s).includes('원본 품질 검사 미실행'));assert(render({...s,qualityChecked:true,qualityStatus:'passed'}).includes('원본 품질 검사 미실행'));
assert.throws(()=>validate({...s,totalAmount:0}),/합계/);assert.throws(()=>validate({...s,inputRows:42}),/등식/);assert.throws(()=>validate({...s,totalAmount:'2363300'}),/정수/);
const x={...s,byDepartment:{'<img onerror=alert(1)>':s.totalAmount}};const text=render(x,{queriedAt:'<script>bad</script>'});assert(!text.includes('<img onerror'));assert(text.includes('&lt;img'));assert(!text.includes('<script>bad'));
assert.throws(()=>render(s,{sheetURL:'javascript:alert(1)'}),/URL/);
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'sheet-report-'));fs.mkdirSync(path.join(dir,'output/sample'),{recursive:true});const target=path.join(dir,'output/sample');
try{
 fs.writeFileSync(path.join(target,'summary.json'),JSON.stringify(s));let r=spawnSync(process.execPath,[file],{cwd:dir,encoding:'utf8'});assert.equal(r.status,0,r.stderr);const first=fs.readFileSync(path.join(target,'report.html'));
 r=spawnSync(process.execPath,[file],{cwd:dir,encoding:'utf8'});assert.equal(r.status,0);assert(first.equals(fs.readFileSync(path.join(target,'report.html'))));
 fs.writeFileSync(path.join(target,'summary.json'),JSON.stringify({...s,totalAmount:0}));r=spawnSync(process.execPath,[file],{cwd:dir,encoding:'utf8'});assert.equal(r.status,1);assert(first.equals(fs.readFileSync(path.join(target,'report.html'))));
 const out=path.join(root,'강사용/결과예시/sheets-report');fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'summary.json'),JSON.stringify(s,null,2)+'\n');fs.writeFileSync(path.join(out,'report.html'),render(s,{queriedAt:'교육용 Excel 가상 데이터의 완료 예시 · Google 실호출 미확인'}));
 const report={passed:9,kind:'actual local code execution; synthetic workbook-derived snapshot',assertions:['workbook-contract total','snapshot renderer always displays raw quality not checked','sum mismatch stops','row equation mismatch stops','numeric type rejection','HTML escaping','URL scheme validation','repeated code execution same bytes','failed input preserves last successful report'],google_live:'not_run'};
 fs.writeFileSync(path.join(__dirname,'sheets-report-verification.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
}finally{fs.rmSync(dir,{recursive:true,force:true})}
