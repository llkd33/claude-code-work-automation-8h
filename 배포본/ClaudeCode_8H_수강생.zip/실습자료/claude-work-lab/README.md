# Claude Code 실습 자료

## 요청을 받으면
- 파일 목록을 보고 요청과 관련된 안내·예시만 읽습니다. 폴더 전체를 매번 읽지 않습니다.
- 짧게 답하고, 필요한 기준만 사용자에게 묻습니다. 이미 받은 답은 다시 묻지 않습니다.
- 자료에 없는 설치·사용법은 필요한 경우 공식 웹 문서에서 확인합니다. 회사 사실·누락된 수치·사용자 취향은 웹검색으로 채우지 않습니다.
- 원본과 기존 정상 결과는 보존합니다. 비용 계산은 제공 도구를 사용하고 오류가 나면 멈춥니다.
- 실제로 확인하지 못한 것은 알려줍니다.

## 필요한 자료 찾기
| 요청 | 먼저 볼 안내 |
|---|---|
| 체크리스트 | templates/checklist-spec.md |
| 회의록 스킬 | input/hanbit-sales/README.md, templates/skills/meeting-minutes/스킬_빈칸양식.md |
| 비용 계산 | integrations/local-report/실행안내.md |
| 보고서·메일 초안 | input/weekly-report/README.md |
| 고객관리 | templates/customer-app/01_고객관리_스펙.md |

## 실습 순서
1. 체크리스트를 만듭니다.
2. 회의록 스킬을 만들고 두 메모에 적용합니다.
3. 비용표 사본으로 보고서를 만들고 오류·복구를 확인합니다.
4. weekly-report 스킬과 CLAUDE.md로 같은 일을 다시 씁니다.

팀·Gmail·실행기·자동 갱신·고객관리 앱은 선택입니다.
[단계별 가이드](단계별_실습가이드.md) · [가상 회사 자료](input/hanbit-sales/README.md)
